package com.examen;

public interface Main {

    double calcularValor();

}
