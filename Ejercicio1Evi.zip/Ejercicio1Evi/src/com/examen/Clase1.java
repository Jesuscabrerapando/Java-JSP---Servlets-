package com.examen;

public class Clase1 {

    private int unidadesEnStock;

    private int unidadesEnPedido;

    private String fechaCaducidad;



    public Clase1(int unidadesEnStock, int unidadesEnPedido, String fechaCaducidad) {

        this.unidadesEnStock = unidadesEnStock;

        this.unidadesEnPedido = unidadesEnPedido;

        this.fechaCaducidad = fechaCaducidad;

    }



    // Getters y Setters



    public int getUnidadesEnStock() {

        return unidadesEnStock;

    }



    public void setUnidadesEnStock(int unidadesEnStock) {

        this.unidadesEnStock = unidadesEnStock;

    }



    public int getUnidadesEnPedido() {

        return unidadesEnPedido;

    }



    public void setUnidadesEnPedido(int unidadesEnPedido) {

        this.unidadesEnPedido = unidadesEnPedido;

    }



    public String getFechaCaducidad() {

        return fechaCaducidad;

    }



    public void setFechaCaducidad(String fechaCaducidad) {

        this.fechaCaducidad = fechaCaducidad;

    }

}