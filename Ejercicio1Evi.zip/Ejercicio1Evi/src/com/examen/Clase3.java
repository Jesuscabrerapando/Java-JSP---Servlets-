package com.examen;

import java.util.ArrayList;

import java.util.List;



public class Clase3 {

    public static void main(String[] args) {

        List<Clase2> productos = new ArrayList<>();



        // Añadir productos

        Clase2 manzana = new Clase2("Manzana", 100, 80, "15/03/2021", 9.95);

        productos.add(manzana);



        Clase2 peras = new Clase2("Peras", 150, 95, "21/03/2021", 15.95);

        productos.add(peras);



        Clase2 naranjas = new Clase2("Naranjas", 100, 75, "20/03/2021", 7.95);

        productos.add(naranjas);



        // Mostrar el total de inventario valorado por su precio

        double valorTotalInventario = 0.0;

        for (Clase2 producto : productos) {

            int inventario = producto.getUnidadesEnStock() - producto.getUnidadesEnPedido();

            double valorProducto = inventario * producto.getPrecioUnitario();

            valorTotalInventario += valorProducto;



            System.out.println("Producto: " + producto.getNombreProducto());

            System.out.println("Inventario: " + inventario);

            System.out.println("Valor: " + valorProducto);

            System.out.println("---------------------------");

        }



        System.out.println("Valor total del inventario: " + valorTotalInventario);

    }

}