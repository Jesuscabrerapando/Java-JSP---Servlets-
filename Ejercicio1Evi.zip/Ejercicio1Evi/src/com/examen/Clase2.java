package com.examen;

public class Clase2 extends Clase1 implements Main {

    private String nombreProducto;

    private double precioUnitario;



    public Clase2(String nombreProducto, int unidadesEnStock, int unidadesEnPedido, String fechaCaducidad, double precioUnitario) {

        super(unidadesEnStock, unidadesEnPedido, fechaCaducidad);

        this.nombreProducto = nombreProducto;

        this.precioUnitario = precioUnitario;

    }



    // Getters y Setters



    public String getNombreProducto() {

        return nombreProducto;

    }



    public void setNombreProducto(String nombreProducto) {

        this.nombreProducto = nombreProducto;

    }



    public double getPrecioUnitario() {

        return precioUnitario;

    }



    public void setPrecioUnitario(double precioUnitario) {

        this.precioUnitario = precioUnitario;

    }



    public double calcularValor() {

        return (getUnidadesEnStock() - getUnidadesEnPedido()) * getPrecioUnitario();

    }

}