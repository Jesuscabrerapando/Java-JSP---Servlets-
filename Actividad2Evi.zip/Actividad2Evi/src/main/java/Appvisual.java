import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Appvisual extends JFrame {
    private JTextField emailField;
    private JTextField stockField;
    private JComboBox<String> paymentMethodComboBox;
    private JComboBox<String> productComboBox;
    private JCheckBox privacyCheckbox;
    private JButton buyButton;
    private JButton calculateButton;
    private JButton checkoutButton;

    private double totalPrice = 0.0;

    public Appvisual() {
        setTitle("Visual Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        getContentPane().setBackground(Color.ORANGE);
        setLayout(new FlowLayout());

        JLabel emailLabel = new JLabel("Correo electrónico:");
        emailField = new JTextField(20);

        JLabel stockLabel = new JLabel("Unidades en stock:");
        stockField = new JTextField(5);

        JLabel paymentMethodLabel = new JLabel("Método de pago:");
        String[] paymentMethods = {"Tarjeta", "PayPal", "Efectivo"};
        paymentMethodComboBox = new JComboBox<>(paymentMethods);

        JLabel productLabel = new JLabel("Producto:");
        String[] products = {"Mesa", "Silla", "Lámpara", "Sofá"};
        productComboBox = new JComboBox<>(products);

        privacyCheckbox = new JCheckBox("Aceptar política de privacidad");

        buyButton = new JButton("Comprar");
        buyButton.setEnabled(false);

        calculateButton = new JButton("Calcular precio");

        checkoutButton = new JButton("Finalizar compra");
        checkoutButton.setEnabled(false);

        add(emailLabel);
        add(emailField);
        add(stockLabel);
        add(stockField);
        add(paymentMethodLabel);
        add(paymentMethodComboBox);
        add(productLabel);
        add(productComboBox);
        add(privacyCheckbox);
        add(buyButton);
        add(calculateButton);
        add(checkoutButton);

        privacyCheckbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buyButton.setEnabled(privacyCheckbox.isSelected());
            }
        });

        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String product = (String) productComboBox.getSelectedItem();
                JOptionPane.showMessageDialog(Appvisual.this, "Has comprado un(a) " + product);
            }
        });

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String product = (String) productComboBox.getSelectedItem();
                int stock = Integer.parseInt(stockField.getText());

                switch (product) {
                    case "Mesa":
                        totalPrice = 7.95 * stock;
                        break;
                    case "Silla":
                        totalPrice = 15.95 * stock;
                        break;
                    case "Lámpara":
                        totalPrice = 25.50 * stock;
                        break;
                    case "Sofá":
                        totalPrice = 9.99 * stock;
                        break;
                }

                JOptionPane.showMessageDialog(Appvisual.this, "El importe total sin IVA es: " + totalPrice);
                checkoutButton.setEnabled(true);
            }
        });

        checkoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isUrgentShipping = JOptionPane.showConfirmDialog(Appvisual.this, "¿Envío urgente?") == JOptionPane.YES_OPTION;

                if (isUrgentShipping) {
                    totalPrice += 9.99;
                }

                totalPrice *= 1.21; // Aplica el IVA del 21%

                JOptionPane.showMessageDialog(Appvisual.this, "El precio final es: " + totalPrice);
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Appvisual app = new Appvisual();
                app.setVisible(true);
            }
        });
    }
}
