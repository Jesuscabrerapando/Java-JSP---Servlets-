import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GuardarAsignaturasServlet")
public class Asignaturas extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String programacion = request.getParameter("programacion");
        String basesDeDatos = request.getParameter("basesDeDatos");
        String lenguajeDeMarcas = request.getParameter("lenguajeDeMarcas");
        String entornosDeDesarrollo = request.getParameter("entornosDeDesarrollo");
        String sistemasOperativos = request.getParameter("sistemasOperativos");

        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO asignaturas (asignatura) VALUES (?)"
            );

            stmt.setString(1, programacion);
            stmt.executeUpdate();

            stmt.setString(1, basesDeDatos);
            stmt.executeUpdate();

            stmt.setString(1, lenguajeDeMarcas);
            stmt.executeUpdate();

            stmt.setString(1, entornosDeDesarrollo);
            stmt.executeUpdate();

            stmt.setString(1, sistemasOperativos);
            stmt.executeUpdate();

            stmt.close();
            conn.close();

            response.sendRedirect("Finalizado.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("Error.jsp");
        }
    }

    private Connection getConnection() throws SQLException {
    	String jdbcUrl = "jdbc:mysql://localhost:3306/test/evidencia3";
    	String username = "";
    	String password = "";
        return DriverManager.getConnection(jdbcUrl, username, password);
    }
}
