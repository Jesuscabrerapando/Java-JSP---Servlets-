package com.teoria;

public class Incidencia {
    private String descripcion;
    private String prioridad;
    private int unidades;
    
    // Constructor
    public Incidencia(String descripcion, String prioridad, int unidades) {
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.unidades = unidades;
    }
    
    // Getters y setters
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public String getPrioridad() {
        return prioridad;
    }
    
    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }
    
    public int getUnidades() {
        return unidades;
    }
    
    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }
}