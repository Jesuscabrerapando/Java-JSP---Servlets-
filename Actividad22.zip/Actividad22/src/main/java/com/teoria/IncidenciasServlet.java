package com.teoria;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Conectar")
public class IncidenciasServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public IncidenciasServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
            
            String insertar = "INSERT INTO dudas (descripcion, prioridad, unidades) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertar);
            ps.setString(1, request.getParameter("d"));
            ps.setString(2, request.getParameter("p"));
            ps.setInt(3, Integer.parseInt(request.getParameter("u")));
            ps.executeUpdate();
            response.getWriter().append("Registro insertado");
            
            // Recuperar las incidencias de la base de datos
            String select = "SELECT descripcion, prioridad, unidades FROM dudas ORDER BY id DESC LIMIT 10";
            PreparedStatement psSelect = conn.prepareStatement(select);
            ResultSet rs = psSelect.executeQuery();
            
            // Crear una lista para almacenar las incidencias
            List<Incidencia> incidencias = new ArrayList<>();
            
            // Iterar sobre los resultados y crear objetos de incidencia
            while (rs.next()) {
                String descripcion = rs.getString("descripcion");
                String prioridad = rs.getString("prioridad");
                int unidades = rs.getInt("unidades");
                
                Incidencia incidencia = new Incidencia(descripcion, prioridad, unidades);
                incidencias.add(incidencia);
            }
            
            // Cerrar las conexiones y liberar los recursos
            rs.close();
            psSelect.close();
            ps.close();
            conn.close();
            
            // Guardar la lista de incidencias como atributo en la solicitud
            request.setAttribute("incidencias", incidencias);
            
            // Redirigir a la página de incidencias.jsp después de insertar la incidencia
            request.getRequestDispatcher("incidencias.jsp").forward(request, response);
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}